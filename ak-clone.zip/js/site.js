/* Shared site behaviour: mobile nav toggle + luxury scroll reveal. */
(function () {
  "use strict";

  document.documentElement.classList.add("js");

  /* ---- Mobile navigation toggle ---- */
  var toggle = document.getElementById("navToggle");
  var links = document.getElementById("navLinks");
  if (toggle && links) {
    function closeMenu() {
      links.classList.remove("is-open");
      toggle.setAttribute("aria-expanded", "false");
    }
    toggle.addEventListener("click", function () {
      var open = links.classList.toggle("is-open");
      toggle.setAttribute("aria-expanded", String(open));
    });
    links.addEventListener("click", function (event) {
      if (event.target.closest("a")) closeMenu();
    });
  }

  /* ---- Scroll reveal ----
     Elements are only hidden once the .reveal class is added here, so the
     page is fully usable without javascript and there is no flash: items
     already in view are revealed immediately; only off-screen items animate. */
  var reduce = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  if (reduce || !("IntersectionObserver" in window)) return;

  var selector = [
    ".section-title", ".title-rule", ".hero__lead", ".hero__actions",
    ".feature", ".spec-card", ".why__item", ".svc-card", ".proj-card", ".featured__cta",
    ".step", ".core-card", ".cta__inner",
    ".story__text", ".story__portrait", ".story__leader", ".journey__step",
    ".values__intro", ".value", ".extra__content",
    ".details__card", ".talk", ".form-wrap", ".expect__item", ".prose"
  ].join(",");

  var els = Array.prototype.slice.call(document.querySelectorAll(selector));
  if (!els.length) return;

  var io = new IntersectionObserver(function (entries) {
    entries.forEach(function (entry) {
      if (entry.isIntersecting) {
        entry.target.classList.add("is-visible");
        io.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12, rootMargin: "0px 0px -6% 0px" });

  var viewport = window.innerHeight || document.documentElement.clientHeight;

  els.forEach(function (el) {
    // Gentle stagger for items sharing a parent (e.g. cards in a grid).
    var siblings = el.parentElement ? el.parentElement.children : [el];
    var index = Array.prototype.indexOf.call(siblings, el);
    el.style.transitionDelay = (Math.min(index, 4) * 0.07) + "s";

    if (el.getBoundingClientRect().top < viewport * 0.92) {
      // Already in view on load — show without hiding first (no flash).
      el.classList.add("reveal", "is-visible");
    } else {
      el.classList.add("reveal");
      io.observe(el);
    }
  });
})();
